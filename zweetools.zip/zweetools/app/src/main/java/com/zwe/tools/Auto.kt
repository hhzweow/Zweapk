package com.zwe.tools

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AutoQueue {
    @Volatile var pending: String? = null
    @Volatile var sender: (() -> Unit)? = null
    fun take(): String? {
        val p = pending
        pending = null
        return p
    }
}

fun isRu(c: Context): Boolean {
    val l = c.getSharedPreferences("zwe", Context.MODE_PRIVATE).getString("lang", "auto")
    return if (l == "auto") Locale.getDefault().language == "ru" else l == "ru"
}

fun tr(c: Context, uz: String, ru: String): String = if (isRu(c)) ru else uz

data class Rule(val w: String, val r: String, val sp: Boolean)

fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("zwe", Context.MODE_PRIVATE)

fun defaultRules(): String =
    "yordam=>Assalomu alaykum, kuting! #sp\n" +
    "help=>Assalomu alaykum, kuting! #sp\n" +
    "admin=>Assalomu alaykum, kuting! #sp\n" +
    "йордам=>Assalomu alaykum, kuting! #sp\n" +
    "хелп=>Assalomu alaykum, kuting! #sp\n" +
    "+=>Assalomu alaykum, kuting!\n" +
    "tk=>Assalomu alaykum, Dalilingiz bo'lsa shikoyat yuboring.\n" +
    "dm=>Assalomu alaykum, Dalilingiz bo'lsa shikoyat yuboring.\n" +
    "db=>Assalomu alaykum, Dalilingiz bo'lsa shikoyat yuboring."

fun parseRules(c: Context): List<Rule> {
    val s = prefs(c).getString("rules", null) ?: defaultRules()
    val out = ArrayList<Rule>()
    for (line in s.split("\n")) {
        val i = line.indexOf("=>")
        if (i <= 0) continue
        val w = line.substring(0, i).trim().lowercase()
        var r = line.substring(i + 2).trim()
        var sp = false
        if (r.endsWith("#sp")) { sp = true; r = r.removeSuffix("#sp").trim() }
        if (w.isNotEmpty() && r.isNotEmpty()) out.add(Rule(w, r, sp))
    }
    return out
}

fun addLog(c: Context, s: String) {
    val p = prefs(c)
    val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    val n = ((p.getString("log", "") ?: "") + "\n" + t + " " + s).takeLast(8000)
    p.edit().putString("log", n).apply()
}

private fun dayKey(): String = "cnt" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
fun bump(c: Context) {
    val p = prefs(c)
    p.edit().putInt(dayKey(), p.getInt(dayKey(), 0) + 1).apply()
}
fun todayCount(c: Context): Int = prefs(c).getInt(dayKey(), 0)

fun weekCounts(c: Context): List<Int> {
    val cal = java.util.Calendar.getInstance()
    cal.firstDayOfWeek = java.util.Calendar.MONDAY
    cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
    val f = SimpleDateFormat("yyyyMMdd", Locale.US)
    val out = ArrayList<Int>()
    for (i in 0 until 7) {
        out.add(prefs(c).getInt("cnt" + f.format(cal.time), 0))
        cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
    }
    return out
}

fun totalCount(c: Context): Int {
    var n = 0
    for ((k, v) in prefs(c).all) if (k.startsWith("cnt") && v is Int) n += v
    return n
}

class ZweAutoService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private val seen = LinkedHashSet<String>()
    private val logged = HashSet<String>()
    private var busy = false
    private var primed = false
    private var lastScan = 0L
    private val ansRe = Regex("""<ADM>\s*([A-Za-z0-9_]+)\[(\d{1,4})\]\s+([A-Za-z0-9_]+)\[(\d{1,4})\]\s+ga javob berdi:\s*([^\n]*)""", RegexOption.IGNORE_CASE)
    private val repRe = Regex("""([A-Za-z0-9_]{2,32})\[(\d{1,4})\]:\s*([^\n\[]+?)\s*\[Hisobotlar soni:\s*(\d+)\]""", RegexOption.IGNORE_CASE)

    override fun onServiceConnected() {
        super.onServiceConnected()
        AutoQueue.sender = { tapAt("sx", "sy", 64.2, 29.6) }
        addLog(this, "Avto-javob xizmati ulandi")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        AutoQueue.sender = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    private fun remember(k: String): Boolean {
        val isNew = seen.add(k)
        if (seen.size > 800) {
            val it = seen.iterator()
            it.next()
            it.remove()
        }
        return isNew
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = prefs(this)
        val auto = p.getBoolean("auto", false)
        val count = p.getBoolean("count", true)
        if (!auto && !count) { primed = false; return }
        val now = System.currentTimeMillis()
        if (now - lastScan < 500) return
        lastScan = now
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName) return
        val texts = ArrayList<String>()
        collect(root, texts, 0)
        if (p.getBoolean("diag", false)) {
            for (t in texts) if (logged.size < 400 && logged.add(t)) addLog(this, "[" + pkg + "] " + t)
        }
        val myId = (p.getString("myid", "30") ?: "30").trim()
        val found = ArrayList<List<String>>()
        val mine = ArrayList<String>()
        for (t in texts) {
            for (m in repRe.findAll(t)) {
                found.add(listOf(m.groupValues[1], m.groupValues[2], m.groupValues[3].trim(), m.groupValues[4]))
            }
            for (m in ansRe.findAll(t)) {
                if (m.groupValues[2] == myId) mine.add(m.value)
            }
        }
        if (!primed) {
            for (f in found) remember(f.joinToString("|").lowercase())
            for (k in mine) remember("A|" + k.lowercase())
            primed = true
            return
        }
        if (count) {
            for (k in mine) if (remember("A|" + k.lowercase())) bump(this)
        }
        if (!auto || busy) return
        val rules = parseRules(this)
        for (f in found) {
            if (!remember(f.joinToString("|").lowercase())) continue
            val low = f[2].lowercase()
            for (r in rules) {
                val re = Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(r.w) + "(?![\\p{L}\\p{N}])")
                if (re.containsMatchIn(low)) {
                    addLog(this, "REPORT " + f[0] + "[" + f[1] + "]: " + f[2] + " -> " + r.w)
                    begin(f[1], r)
                    return
                }
            }
        }
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, d: Int) {
        if (n == null || d > 30) return
        val t = n.text
        if (t != null && t.isNotEmpty()) out.add(t.toString())
        for (i in 0 until n.childCount) collect(n.getChild(i), out, d + 1)
    }

    private fun tapAt(kx: String, ky: String, dx: Double, dy: Double) {
        val p = prefs(this)
        val px = p.getString(kx, null)?.toDoubleOrNull() ?: dx
        val py = p.getString(ky, null)?.toDoubleOrNull() ?: dy
        val dm = DisplayMetrics()
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val path = Path()
        path.moveTo((dm.widthPixels * px / 100.0).toFloat(), (dm.heightPixels * py / 100.0).toFloat())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun begin(id: String, r: Rule) {
        busy = true
        val cmds = ArrayList<String>()
        cmds.add("/ans " + id + " " + r.r)
        if (r.sp) cmds.add("/sp " + id)
        step(cmds, 0)
    }

    private fun step(c: List<String>, i: Int) {
        if (i >= c.size) { busy = false; return }
        val texts = ArrayList<String>()
        collect(rootInActiveWindow, texts, 0)
        val open = texts.any { it.lowercase().contains("kiritish uchun") }
        var delay = 0L
        if (!open) {
            tapAt("ox", "oy", 23.3, 29.6)
            delay = 900L
        }
        h.postDelayed({
            AutoQueue.pending = c[i]
            tapAt("fx", "fy", 38.2, 29.6)
            var waited = 0
            val poll = object : Runnable {
                override fun run() {
                    if (AutoQueue.pending == null) {
                        h.postDelayed({
                            tapAt("sx", "sy", 64.2, 29.6)
                            addLog(this@ZweAutoService, "Yuborildi: " + c[i])
                            h.postDelayed({ step(c, i + 1) }, 1500)
                        }, 600)
                    } else if (waited > 7000) {
                        AutoQueue.pending = null
                        busy = false
                        addLog(this@ZweAutoService, "Vaqt tugadi (klaviatura chiqmadi): " + c[i])
                    } else {
                        waited += 300
                        h.postDelayed(this, 300)
                    }
                }
            }
            h.postDelayed(poll, 700)
        }, delay)
    }
}
