package com.zwe.tools

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var logTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = prefs(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(40, 50, 40, 60)
        val blue = 0xFF4D9BFF.toInt()

        fun t(uz: String, ru: String): String = tr(this, uz, ru)
        fun tv(s: String, size: Float = 15f, c: Int = Color.WHITE): TextView {
            val v = TextView(this)
            v.text = s
            v.textSize = size
            v.setTextColor(c)
            v.setPadding(0, 24, 0, 8)
            return v
        }
        fun bt(s: String, f: () -> Unit): Button {
            val b = Button(this)
            b.text = s
            b.isAllCaps = false
            b.setTextColor(Color.WHITE)
            b.setBackgroundColor(0xFF1E6BFF.toInt())
            b.setOnClickListener { f() }
            return b
        }
        fun sw(s: String, k: String, d: Boolean = false): Switch {
            val w = Switch(this)
            w.text = s
            w.setTextColor(Color.WHITE)
            w.isChecked = p.getBoolean(k, d)
            w.setOnCheckedChangeListener { _, v -> p.edit().putBoolean(k, v).apply() }
            return w
        }
        val fields = ArrayList<Pair<String, EditText>>()
        val defs = HashMap<String, String>()
        fun field(label: String, key: String, def: String, lines: Int = 1) {
            col.addView(tv(label, 13f))
            val e = EditText(this)
            e.setText(p.getString(key, null) ?: def)
            e.setTextColor(Color.WHITE)
            e.minLines = lines
            e.gravity = Gravity.TOP
            col.addView(e)
            fields.add(Pair(key, e))
            defs[key] = def
        }

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        col.addView(logo, LinearLayout.LayoutParams(380, 380).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        val title = tv("Zwe TOOLS 2.0", 26f)
        title.gravity = Gravity.CENTER
        col.addView(title)

        col.addView(sw(t("Avto-javob (ON/OFF)", "Авто-ответ (ВКЛ/ВЫКЛ)"), "auto"))
        col.addView(bt("Discord") {
            val link = p.getString("discord", null) ?: "https://discord.gg/eu3Jmt8RG"
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
            } catch (e: Exception) {
                Toast.makeText(this, link, Toast.LENGTH_LONG).show()
            }
        })

        col.addView(tv(t("Hisobotlar", "Отчёты"), 18f, blue))
        val wk = weekCounts(this)
        val names = if (isRu(this)) listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
        else listOf("Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba", "Yakshanba")
        col.addView(tv(t("Bugun: ", "Сегодня: ") + todayCount(this) + "   " + t("Hafta: ", "Неделя: ") + wk.sum() + "   " + t("Jami: ", "Всего: ") + totalCount(this), 16f))
        for (i in 0 until 7) col.addView(tv(names[i] + ": " + wk[i], 14f, 0xFFB8C4E0.toInt()))
        col.addView(sw(t("Mening javoblarimni sanash", "Считать мои ответы"), "count", true))

        col.addView(tv(t("Klaviatura", "Клавиатура"), 18f, blue))
        col.addView(bt(t("Klaviaturani yoqish", "Включить клавиатуру")) { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        col.addView(bt(t("Klaviaturani tanlash", "Выбрать клавиатуру")) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        col.addView(sw(t("Qo'lda yuborganda Yuborish tugmasini bosish", "Нажимать кнопку отправки при ручной отправке"), "tapsend", true))

        col.addView(tv(t("Avto-javob va sanash", "Авто-ответ и подсчёт"), 18f, blue))
        col.addView(tv(t("Bu funksiya ekrandagi chat matnini oqiydi. Android Maxsus imkoniyatlar ruxsati kerak. Faqat Grand Mobile qoidalari ruxsat bersa yoqing. Istagan payt ozingiz ochirib qoyasiz.",
            "Функция читает текст чата на экране. Нужно разрешение Специальные возможности. Включайте только если правила Grand Mobile разрешают. Отключить можно в любой момент.")))
        col.addView(bt(t("Maxsus imkoniyatlarni ochish", "Открыть спец. возможности")) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.addView(sw(t("Diagnostika (ekran matnini yozib borish)", "Диагностика (запись текста экрана)"), "diag"))

        col.addView(tv(t("Sozlamalar", "Настройки"), 18f, blue))
        col.addView(tv(t("Admin darajasi", "Уровень админа")))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1", "2", "3", "4"))
        sp.setSelection(p.getInt("level", 1) - 1)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                p.edit().putInt("level", pos + 1).apply()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(sp)

        col.addView(tv(t("Til", "Язык")))
        val codes = listOf("auto", "uz", "ru")
        val sl = Spinner(this)
        sl.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Avto / Авто", "Oʻzbekcha", "Русский"))
        sl.setSelection(codes.indexOf(p.getString("lang", "auto") ?: "auto").coerceAtLeast(0))
        sl.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (codes[pos] != (p.getString("lang", "auto") ?: "auto")) {
                    p.edit().putString("lang", codes[pos]).apply()
                    recreate()
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(sl)

        field(t("Mening ID raqamim (hisobotni sanash uchun)", "Мой ID (для подсчёта)"), "myid", "30")
        field(t("Tayyor javoblar (har qatorda bittadan)", "Готовые ответы (по одному в строке)"), "tpl", loadTemplates(this).joinToString("\n"), 4)
        field(t("Avto-javob sozlari. Format: soz=>javob. Javobdan keyin /sp kerak bo'lsa oxiriga #sp qo'shing.",
            "Слова авто-ответа. Формат: слово=>ответ. Если после ответа нужен /sp, добавьте в конец #sp."), "rules", defaultRules(), 8)
        field(t("Vaqt tugmalari (vergul bilan)", "Кнопки времени (через запятую)"), "times", "15,30,60,120,1440")
        field(t("Ban kunlari (vergul bilan)", "Дни бана (через запятую)"), "dtimes", "1,3,7,15,30")
        field(t("Sabab tugmalari (vergul bilan)", "Кнопки причин (через запятую)"), "reasons", "NonRP,DM,TK,SK,Flood,Mat,Reklama")
        field(t("Discord havolasi", "Ссылка Discord"), "discord", "https://discord.gg/eu3Jmt8RG")
        col.addView(tv(t("Tugmalar joyi (ekranning foizi). Odatda ozgartirish shart emas.", "Положение кнопок (% экрана). Обычно менять не нужно."), 13f))
        field(t("Chat ochish X %", "Открыть чат X %"), "ox", "23.3")
        field(t("Chat ochish Y %", "Открыть чат Y %"), "oy", "29.6")
        field(t("Yozish maydoni X %", "Поле ввода X %"), "fx", "38.2")
        field(t("Yozish maydoni Y %", "Поле ввода Y %"), "fy", "29.6")
        field(t("Yuborish X %", "Отправить X %"), "sx", "64.2")
        field(t("Yuborish Y %", "Отправить Y %"), "sy", "29.6")

        col.addView(bt(t("SAQLASH", "СОХРАНИТЬ")) {
            val ed = p.edit()
            for ((k, e) in fields) {
                var v = e.text.toString().trim()
                if (k.length == 2 && v.toDoubleOrNull() == null) v = defs[k] ?: v
                ed.putString(k, v)
            }
            ed.apply()
            Toast.makeText(this, t("Saqlandi", "Сохранено"), Toast.LENGTH_SHORT).show()
        })

        col.addView(tv(t("Jurnal", "Журнал"), 18f, blue))
        logTv = tv(p.getString("log", "") ?: "", 12f, 0xFFB8C4E0.toInt())
        col.addView(logTv)
        col.addView(bt(t("Jurnalni yangilash", "Обновить журнал")) { logTv.text = prefs(this).getString("log", "") ?: "" })
        col.addView(bt(t("Jurnalni tozalash", "Очистить журнал")) {
            prefs(this).edit().putString("log", "").apply()
            logTv.text = ""
        })

        col.addView(tv(t("Sinov maydoni", "Поле для проверки")))
        val test = EditText(this)
        test.hint = t("Bu yerga yozib klaviaturani sinang", "Напишите здесь для проверки клавиатуры")
        test.setTextColor(Color.WHITE)
        col.addView(test)

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF05070D.toInt())
        sv.addView(col)
        setContentView(sv)
    }
}
