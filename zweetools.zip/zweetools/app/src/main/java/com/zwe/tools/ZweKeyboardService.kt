package com.zwe.tools

import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ZweKeyboardService : InputMethodService() {
    private lateinit var root: LinearLayout
    private val ui = Handler(Looper.getMainLooper())
    private var mode = "keys"
    private var ru = false
    private var shift = false
    private var sym = false
    private var idBuf = ""
    private var pending: Cmd? = null
    private var replyText: String? = null
    private var quickId = ""
    private var ptime = ""
    private var active = false
    private val checker: Runnable = object : Runnable {
        override fun run() {
            val j = AutoQueue.take()
            if (j != null) {
                if (currentInputConnection != null) put(j) else AutoQueue.pending = j
            }
            if (active) ui.postDelayed(this, 300)
        }
    }

    private val cKey = 0xFF141B2D.toInt()
    private val cFn = 0xFF1E6BFF.toInt()
    private val cGray = 0xFF2A3350.toInt()
    private val cRed = 0xFF8A2A2A.toInt()
    private val cGreen = 0xFF1B8F4C.toInt()

    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val rus = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
    private val symRows = listOf("1234567890", "@#$%&-+()/", "*\"':;!?,._")
    private val banCmds = listOf("ban", "sban", "offban")

    override fun onCreateInputView(): View {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF05070D.toInt())
        root.setPadding(dp(4), dp(4), dp(4), dp(4))
        draw()
        return root
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::root.isInitialized) draw()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (mode != "quick") mode = "keys"
        pending = null
        replyText = null
        idBuf = ""
        if (::root.isInitialized) draw()
        active = true
        ui.removeCallbacks(checker)
        ui.post(checker)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        active = false
        ui.removeCallbacks(checker)
    }

    private fun s(uz: String, rus: String): String = tr(this, uz, rus)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun land(): Boolean = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun kh(): Int = if (land()) 34 else 46
    private fun listH(): Int = dp(if (land()) 120 else 220)
    private fun level(): Int = prefs(this).getInt("level", 1)
    private fun put(t: String) { currentInputConnection?.commitText(t, 1) }

    private fun lst(key: String, def: String): List<String> =
        (prefs(this).getString(key, def) ?: def).split(",").map { it.trim() }.filter { it.isNotEmpty() }

    private fun btn(label: String, bg: Int = cKey, w: Float = 1f, h: Int = 0, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = if (land()) 14f else 16f
        b.setPadding(0, 0, 0, 0)
        val g = GradientDrawable()
        g.cornerRadius = dp(10).toFloat()
        g.setColor(bg)
        b.background = g
        val hh = dp(if (h == 0) kh() else h)
        val lp = if (w < 0f) LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, hh)
        else LinearLayout.LayoutParams(0, hh, w)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        for (x in v) r.addView(x)
        return r
    }

    private fun title(t: String) {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = if (land()) 14f else 18f
        v.gravity = Gravity.CENTER
        v.setPadding(0, dp(3), 0, dp(3))
        root.addView(v)
    }

    private fun scroller(box: LinearLayout) {
        val sv = ScrollView(this)
        sv.addView(box)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, listH())
        root.addView(sv)
    }

    private fun vbox(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        return b
    }

    private fun draw() {
        root.removeAllViews()
        when (mode) {
            "admin" -> admin()
            "id" -> idPad()
            "tpl" -> tplList()
            "quick" -> quick()
            "tm" -> timePick()
            "rs" -> reasonPick()
            else -> keys()
        }
    }

    private fun keys() {
        val auto = prefs(this).getBoolean("auto", false)
        root.addView(row(
            btn("Admin", cFn) { mode = "admin"; draw() },
            btn(s("Javoblar", "Ответы"), cFn) { pending = null; replyText = null; mode = "tpl"; draw() },
            btn(if (auto) "AVTO ✓" else "AVTO", if (auto) cGreen else cGray) {
                prefs(this).edit().putBoolean("auto", !auto).apply()
                draw()
            },
            btn(if (ru) "EN" else "RU", cGray) { ru = !ru; draw() },
            btn(if (sym) "ABC" else "123", cGray) { sym = !sym; draw() }
        ))
        val rows = if (sym) symRows else listOf("1234567890") + (if (ru) rus else en)
        for (r in rows) {
            val keyViews = r.map { ch ->
                val k = if (shift && !sym) ch.toString().uppercase() else ch.toString()
                btn(k, cKey) {
                    put(k)
                    if (shift) { shift = false; draw() }
                }
            }
            root.addView(row(*keyViews.toTypedArray()))
        }
        root.addView(row(
            btn("⇧", if (shift) cFn else cGray, 1.3f) { shift = !shift; draw() },
            btn(if (ru) "Русский" else "English", cKey, 4f) { put(" ") },
            btn("⌫", cGray, 1.3f) { currentInputConnection?.deleteSurroundingText(1, 0) },
            btn("⏎", cFn, 1.3f) { enter() }
        ))
    }

    private fun enter() {
        if (!sendDefaultEditorAction(true)) {
            val ic = currentInputConnection ?: return
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun submit() {
        val f = AutoQueue.sender
        if (f != null && prefs(this).getBoolean("tapsend", true)) f() else enter()
    }

    private fun resetFlow() {
        pending = null
        replyText = null
        idBuf = ""
        ptime = ""
        mode = "keys"
        draw()
    }

    private fun sendRaw(t: String) {
        put(t)
        ui.postDelayed({ submit() }, 250)
    }

    private fun sendAns(id: String, text: String) {
        sendRaw("/ans " + id + " " + text)
        if (AutoQueue.sender == null) bump(this)
        quickId = id
        pending = null
        replyText = null
        idBuf = ""
        mode = "quick"
        draw()
    }

    private fun recentIds(): List<String> = lst("ids", "")

    private fun saveId(id: String) {
        val l = (listOf(id) + recentIds().filter { it != id }).take(5)
        prefs(this).edit().putString("ids", l.joinToString(",")).apply()
    }

    private fun insertCmd(c: Cmd, id: String, extra: String = "") {
        val rest = c.f.replace("i", "")
        put("/" + c.n + (if (id.isNotEmpty()) " $id" else "") + (if (extra.isNotEmpty()) " $extra" else "") + (if (rest.isNotEmpty()) " " else ""))
    }

    private fun admin() {
        root.addView(btn("← ABC", cGray, -1f, if (land()) 30 else 40) { mode = "keys"; draw() })
        val box = vbox()
        for (chunk in CMDS.filter { it.l <= level() }.chunked(3)) {
            val bs = chunk.map { c ->
                btn("/" + c.n, cKey) {
                    pending = c
                    replyText = null
                    idBuf = ""
                    ptime = ""
                    if (c.f.contains('i')) {
                        mode = "id"
                    } else {
                        insertCmd(c, "")
                        mode = "keys"
                    }
                    draw()
                }
            }
            box.addView(row(*bs.toTypedArray()))
        }
        scroller(box)
    }

    private fun idPad() {
        val c = pending
        if (c == null) { mode = "keys"; draw(); return }
        val rt = replyText
        title("/" + c.n + "   ID: " + idBuf + (if (rt != null) "  ·  " + rt.take(30) else ""))
        val rec = recentIds()
        if (rec.isNotEmpty()) {
            val rs = rec.map { id -> btn(id, cGray, 1f, if (land()) 28 else 36) { idBuf = id; draw() } }
            root.addView(row(*rs.toTypedArray()))
        }
        for (r in listOf("123", "456", "789")) {
            val ds = r.map { d -> btn(d.toString(), cKey) { if (idBuf.length < 7) idBuf += d; draw() } }
            root.addView(row(*ds.toTypedArray()))
        }
        root.addView(row(
            btn("C", cRed) { idBuf = ""; draw() },
            btn("0", cKey) { if (idBuf.length < 7) idBuf += "0"; draw() },
            btn("⌫", cRed) { idBuf = idBuf.dropLast(1); draw() }
        ))
        val ok = if (c.n == "ans" && rt != null) s("Yuborish ➤", "Отправить ➤") else s("Davom →", "Далее →")
        root.addView(row(
            btn(s("← Orqaga", "← Назад"), cGray) {
                if (rt != null) { pending = null; mode = "tpl" } else { mode = "admin" }
                draw()
            },
            btn(ok, cFn) {
                if (idBuf.isNotEmpty()) {
                    saveId(idBuf)
                    val simple = c.f.all { it == 'i' || it == 't' || it == 'r' }
                    if (c.n == "ans" && rt != null) {
                        sendAns(idBuf, rt)
                    } else if (c.n == "ans") {
                        mode = "tpl"
                        draw()
                    } else if (simple && (c.f.contains('t') || c.f.contains('r'))) {
                        ptime = ""
                        mode = if (c.f.contains('t')) "tm" else "rs"
                        draw()
                    } else {
                        insertCmd(c, idBuf)
                        mode = "keys"
                        draw()
                    }
                }
            }
        ))
    }

    private fun chips(items: List<String>, onPick: (String) -> Unit, back: () -> Unit, manual: () -> Unit) {
        val box = vbox()
        for (chunk in items.chunked(4)) {
            val bs = chunk.map { v -> btn(v, cKey) { onPick(v) } }
            box.addView(row(*bs.toTypedArray()))
        }
        box.addView(row(
            btn(s("← Orqaga", "← Назад"), cGray) { back() },
            btn(s("✎ Qo'lda", "✎ Вручную"), cGray) { manual() }
        ))
        scroller(box)
    }

    private fun timePick() {
        val c = pending
        if (c == null) { mode = "keys"; draw(); return }
        title("/" + c.n + " " + idBuf + " — " + s("Vaqt", "Время"))
        val items = if (banCmds.contains(c.n)) lst("dtimes", "1,3,7,15,30") else lst("times", "15,30,60,120,1440")
        chips(items, { v ->
            ptime = v
            if (c.f.contains('r')) { mode = "rs"; draw() } else { sendRaw("/" + c.n + " " + idBuf + " " + v); resetFlow() }
        }, { mode = "id"; draw() }, { insertCmd(c, idBuf); mode = "keys"; draw() })
    }

    private fun reasonPick() {
        val c = pending
        if (c == null) { mode = "keys"; draw(); return }
        title("/" + c.n + " " + idBuf + " " + ptime + " — " + s("Sabab", "Причина"))
        chips(lst("reasons", "NonRP,DM,TK,SK,Flood,Mat,Reklama"), { v ->
            sendRaw("/" + c.n + " " + idBuf + (if (ptime.isNotEmpty()) " $ptime" else "") + " " + v)
            resetFlow()
        }, { mode = if (ptime.isNotEmpty()) "tm" else "id"; draw() }, {
            insertCmd(c, idBuf, ptime)
            mode = "keys"
            draw()
        })
    }

    private fun quick() {
        root.addView(btn("← ABC", cGray, -1f, if (land()) 30 else 40) { mode = "keys"; draw() })
        title(s("Tezkor buyruq", "Быстрые команды") + "  ID: " + quickId)
        val box = vbox()
        for (chunk in CMDS.filter { it.f == "i" && it.l <= level() }.chunked(3)) {
            val bs = chunk.map { c -> btn("/" + c.n, cKey) { sendRaw("/" + c.n + " " + quickId) } }
            box.addView(row(*bs.toTypedArray()))
        }
        scroller(box)
    }

    private fun tplList() {
        root.addView(btn("← ABC", cGray, -1f, if (land()) 30 else 40) {
            mode = if (pending != null) "id" else "keys"
            draw()
        })
        val box = vbox()
        for (tx in loadTemplates(this)) {
            box.addView(btn(tx, cKey, -1f, if (land()) 40 else 52) {
                val p = pending
                if (p != null && p.n == "ans" && idBuf.isNotEmpty()) {
                    sendAns(idBuf, tx)
                } else {
                    replyText = tx
                    pending = CMDS.first { it.n == "ans" }
                    idBuf = ""
                    mode = "id"
                    draw()
                }
            })
        }
        scroller(box)
    }
}
