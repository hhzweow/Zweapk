plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.zwe.tools"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.zwe.tools"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "2.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
